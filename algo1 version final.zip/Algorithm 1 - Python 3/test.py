from random import seed
from algorithm_1 import City, generate_list_of_vehicles, generate_list_of_products, algorithm, make_solution_report

seed(3)

warehouse_x = 0
warehouse_y = 0

number_of_products = 30

list_of_vehicles = generate_list_of_vehicles(warehouse_x, warehouse_y)

list_of_products = generate_list_of_products(number_of_products, warehouse_x, warehouse_y)

max_iterations = 50

city = City("city.txt")
# print(city)

best_solution_vehicles, best_solution_products, best_fitness = algorithm(max_iterations, list_of_vehicles, list_of_products, city, warehouse_x, warehouse_y)

make_solution_report(best_solution_vehicles, best_solution_products)