from random import randint, shuffle, sample
from math import ceil
from heapq import heappush, heappop, heapify
import math

class Vehicle(object):
  def __init__(self, identifier, capacity, velocity, x, y):
    self.identifier = identifier
    self.capacity = capacity
    self.velocity = velocity
    self.x = x
    self.y = y
    self.path = list()
  
  def update_capacity(self, value):
    self.capacity -= value
  
  def update_path(self, new_path):
    if new_path == None:
      raise ValueError("No se encontró un path para el vehículo {}".format(self.identifier))
    
    self.path.extend(new_path)

class Motorcycle(Vehicle):
  def __init__(self, identifier, capacity, velocity, x, y):
    super().__init__(identifier, capacity, velocity, x, y)

class Car(Vehicle):
  def __init__(self, identifier, capacity, velocity, x, y):
    super().__init__(identifier, capacity, velocity, x, y)

class Product(object):
  def __init__(self, identifier, x, y, remaining_time):
    self.identifier = identifier
    self.x = x
    self.y = y
    self.remaining_time = remaining_time

def process_flow(n):
  return n.capacity * n.velocity

def process_desirability(warehouse_x, warehouse_y):
  def process_desirability_function(n):
    estimated_distance = abs(warehouse_x - n.x) + abs(warehouse_y - n.y)
    return 1 / (estimated_distance * n.remaining_time)
  return process_desirability_function

def fitness(solution_vehicles, solution_products):
  cumulative_fitness = 0
  
  for vehicle, product in zip(solution_vehicles, solution_products):
    estimated_distance = abs(vehicle.x - product.x) + abs(vehicle.y - product.y)
    
    estimated_arriving_time = estimated_distance / vehicle.velocity
    
    margin_time = product.remaining_time - estimated_arriving_time
    
    penalty = 0.5 if margin_time < 0 else 2
    
    abs_margin_time = abs(margin_time)

    if abs_margin_time > 1:
      penalty *= abs_margin_time

    if isinstance(vehicle, Motorcycle) == True:
      factor = 2
    else:
      factor = 0.8

    cumulative_fitness +=  vehicle.capacity * penalty * factor
  
  return cumulative_fitness

def greedy_randomized_construction(list_of_vehicles, list_of_products, alpha, warehouse_x, warehouse_y):
  number_of_vehicles = len(list_of_vehicles)
  number_of_products = len(list_of_products)

  list_of_vehicles_by_flow = sorted(list_of_vehicles, key=process_flow, reverse=True)
  
  list_of_products_by_desirability = sorted(list_of_products, key=process_desirability(warehouse_x, warehouse_y), reverse=True)
  
  solution_products = []
  solution_vehicles = []
  
  products_to_assign = number_of_products if number_of_products <= number_of_vehicles else number_of_vehicles

  for _ in range(products_to_assign):
    first_element = list_of_products_by_desirability[0]
    gamma = process_desirability(warehouse_x, warehouse_y)(first_element)
    
    restricted_candidate_list = [product for product in list_of_products_by_desirability if process_desirability(warehouse_x, warehouse_y)(product) >= (alpha * gamma)]
    
    index = randint(0, len(restricted_candidate_list) - 1)
    random_product_selected = restricted_candidate_list[index]
    list_of_products_by_desirability.pop(index)
    
    solution_products.append(random_product_selected)
    solution_vehicles.append(list_of_vehicles_by_flow[0])
    list_of_vehicles_by_flow.pop(0)
  
  solution_fitness = fitness(solution_vehicles, solution_products)

  return solution_vehicles, solution_products, solution_fitness

def shuffle_list_of_vehicles(list_of_vehicles):
  list_of_vehicles_copy = list_of_vehicles[:]
  
  shuffle(list_of_vehicles_copy)
  
  return list_of_vehicles_copy

def sample_list_of_vehicles(list_of_vehicles, length):
  return sample(list_of_vehicles, length)

def local_search(solution_vehicles, solution_products, solution_fitness, list_of_vehicles, neighbors_size):
  half_neighbors_size = ceil(neighbors_size/2)
  neighborhood_shuffle_of_vehicles = [shuffle_list_of_vehicles(solution_vehicles) for _ in range(half_neighbors_size)]
  neighborhood_sample_of_vehicles = [sample_list_of_vehicles(list_of_vehicles, len(solution_vehicles)) for _ in range(neighbors_size - half_neighbors_size)]
  
  for neighbor_vehicles in neighborhood_shuffle_of_vehicles:
    neighbor_fitness = fitness(solution_vehicles, solution_products)
    if neighbor_fitness > solution_fitness:
      solution_vehicles = neighbor_vehicles
      solution_fitness = neighbor_fitness
  
  for neighbor_vehicles in neighborhood_sample_of_vehicles:
    neighbor_fitness = fitness(solution_vehicles, solution_products)
    if neighbor_fitness > solution_fitness:
      solution_vehicles = neighbor_vehicles
      solution_fitness = neighbor_fitness
  
  return solution_vehicles, solution_products, solution_fitness

def update_solution(solution_vehicles, solution_products, solution_fitness, best_solution_vehicles, best_solution_products, best_fitness):
  if solution_fitness > best_fitness:
    best_solution_vehicles, best_solution_products, best_fitness = solution_vehicles, solution_products, solution_fitness
  
  return best_solution_vehicles, best_solution_products, best_fitness

def grasp(max_iterations, list_of_vehicles, list_of_products, warehouse_x, warehouse_y):
  alpha_max = 0.8
  alpha_min = 0.1
  delta = (alpha_max - alpha_min) / max_iterations
  alpha = alpha_min
  neighbors_size = 20
  
  best_solution_vehicles = []
  best_solution_products = []
  best_fitness = -1
  
  for iteration in range(max_iterations):
    alpha += delta
    solution_vehicles, solution_products, solution_fitness = greedy_randomized_construction(list_of_vehicles, list_of_products, alpha, warehouse_x, warehouse_y)
    
    solution_vehicles, solution_products, solution_fitness = local_search(solution_vehicles, solution_products, solution_fitness, list_of_vehicles, neighbors_size)
    
    best_solution_vehicles, best_solution_products, best_fitness = update_solution(solution_vehicles, solution_products, solution_fitness, best_solution_vehicles, best_solution_products, best_fitness)
  
  return best_solution_vehicles, best_solution_products, best_fitness

class City(object):
  def __init__(self, file_name):
    self.grid = self.read_grid(file_name)
    
    self.num_rows = len(self.grid)
    self.num_cols = len(self.grid[0])
  
  def read_grid(self, file_name):
    with open(file_name) as grid:
      grid_content = [[int(element) for element in line.strip().split(",")] for line in grid.readlines()]
    
    return grid_content

  def is_blocked(self, row, col):
    return self.grid[row][col] == 0
  
  def is_clear(self, row, col):
    return self.grid[row][col] != 0
  
  def get_num_rows(self):
    return self.num_rows

  def get_num_cols(self):
    return self.num_cols

  def get_city_representation(self):
    lines = []
    
    headerLine = " " + ("-" * (self.num_cols)) + " "
    
    lines.append(headerLine)
    
    for row in self.grid:
      row = ["#" if element == 0 else " " for element in row]
      rowLine = "|" + "".join(row) + "|"
      lines.append(rowLine)
    
    lines.append(headerLine)
    
    return "\n".join(lines)

  def __str__(self):
    return self.get_city_representation()

class StateIsBlocked(Exception):
  def __init__(self, m):
    self.message = m
  
  def __str__(self):
    return self.message

class SearchProblem(object):
  def __init__(self, city, initial, goal):
    self.city = city
    self.initial = initial
    self.goal = goal
    
    self.temporal_unblock = False

    if self.city.is_blocked(goal[0], goal[1]):
      self.city.grid[self.goal[0]][self.goal[1]] = 1
      
      self.temporal_unblock = True
      
  def is_valid_state(self,state):
    row,col = state

    if row < 0 or row >= self.city.get_num_rows():
      return False
    elif col < 0 or col >= self.city.get_num_cols():
      return False
    
    return not self.city.is_blocked(row, col)

  def actions(self, state):
    row, col = state
    valid_actions = list()
    
    if self.is_valid_state((row-1, col)):
        valid_actions.append("N")
    
    if self.is_valid_state((row+1, col)):
        valid_actions.append("S")
    
    if self.is_valid_state((row, col-1)):
        valid_actions.append("W")
    
    if self.is_valid_state((row, col+1)):
        valid_actions.append("E")
    
    return valid_actions
  
  def result(self, state, action):
    row,col = state
    new_state = None
    
    if action == "N":
      new_state = (row-1, col)        
    elif action == "S":
      new_state = (row+1, col)
    elif action == "W":
      new_state = (row, col-1)
    elif action == "E":
      new_state = (row, col+1)
    
    return new_state
  
  def goal_test(self, state):
    return (self.goal == state) 

  def path_cost(self, acummulated_cost, state_1, action, state_2):
    row, col = state_2
    
    if self.city.is_clear(row, col):
      action_cost = 1
    elif (state_2 == self.initial) or (state_2 == self.goal):
      action_cost = 1
    else:
      raise StateIsBlocked("El costo de una celda bloqueada no esta definido")
    
    return acummulated_cost + action_cost
  
  def remove_temporal_unblock(self):
    self.city.grid[self.goal[0]][self.goal[1]] = 0
      
    self.temporal_unblock = False

class Node(object):
  def __init__(self, state, parent=None, action=None, path_cost=0):
    self.state = state
    self.parent = parent
    self.action = action
    self.path_cost = path_cost
    
    if parent:
      self.depth = parent.depth + 1
    else:
      self.depth = 0

  def expand(self, problem):
    return [self.child_node(problem, action) for action in problem.actions(self.state)]

  def child_node(self, problem, action):
    next_state = problem.result(self.state, action)
    
    return Node(next_state, self, action, problem.path_cost(self.path_cost, self.state, action, next_state))

  def solution(self):
    return [node.state for node in self.path()]

  def path(self):
    node, path_back = self, list()

    while node:
      path_back.append(node)
      node = node.parent
    
    return list(reversed(path_back))
  
  def __lt__(self, node):
    return self.state < node.state
  
  def __eq__(self, other): 
    return isinstance(other, Node) and self.state == other.state
  
  def __repr__(self):
    return "<Node {}>".format(self.state)
  
  def __hash__(self):
    return hash(self.state)

class FrontierPriorityQueue(object):
  def __init__(self, initial, costfn=lambda node: node.path_cost):
    self.heap   = list()
    self.states = dict()
    self.costfn = costfn
    self.add(initial)
  
  def add(self, node):
    cost = self.costfn(node)
    heappush(self.heap, (cost, node))
    self.states[node.state] = node
  
  def pop(self):
    (cost, node) = heappop(self.heap)
    self.states.pop(node.state, None)
    return node
  
  def replace(self, node):
    if node.state not in self.states:
      raise ValueError('{} no tiene nada que reemplazar'.format(node.state))
    
    for (i, (cost, old_node)) in enumerate(self.heap):
      if old_node.state == node.state:
        self.heap[i] = (self.costfn(node), node)
        heapify(self.heap)

  def __len__(self):
    return len(self.heap)

def best_first_graph_search(problem, f):
  frontier = FrontierPriorityQueue(Node(problem.initial), f) 
  explored = set()
  visited_nodes = list()
  
  while len(frontier) > 0:
    node = frontier.pop()
    visited_nodes.append(node)
    
    if problem.goal_test(node.state):
      if problem.temporal_unblock == True:
        problem.remove_temporal_unblock()
      
      return node.solution()
    
    explored.add(node.state)
    
    for action in problem.actions(node.state):
      child = node.child_node(problem, action)
      
      if child.state not in explored and child.state not in frontier.states:
        frontier.add(child)
      elif child.state in frontier.states:
        incumbent = frontier.states[child.state] 
        
        if f(child) < f(incumbent):
          frontier.replace(child)
  
  return None

def astar_search(problem, heuristic):
  f = lambda node: node.path_cost + heuristic(node, problem)
  
  return best_first_graph_search(problem, f)

def manhattan_dist(node, problem):
  (s_x , s_y) = node.state
  (g_x , g_y) = problem.goal

  return abs(s_x - g_x) + abs(s_y - g_y)

def generate_list_of_vehicles(x, y, number_of_motorcycles=40, number_of_cars=20, motorcycle_capacity=4, motorcycle_velocity=60, car_capacity=25, car_velocity=30):
  list_of_vehicles = list()

  for vehicle_identifier in range(number_of_motorcycles):
    vehicle = Motorcycle(vehicle_identifier, motorcycle_capacity, motorcycle_velocity, x, y)

    list_of_vehicles.append(vehicle)
  
  for vehicle_identifier in range(number_of_cars):
    vehicle = Car(vehicle_identifier, car_capacity, car_velocity, x, y)

    list_of_vehicles.append(vehicle)
  
  return list_of_vehicles

def generate_list_of_products(number_of_products, warehouse_x, warehouse_y, max_x=70, max_y=50, max_remaining_time=24):
  list_of_products = list()

  for product_identifier in range(number_of_products):
    x = randint(0, max_x)
    while x == warehouse_x:
      x = randint(0, max_x)
    
    y = randint(0, max_y)
    while y == warehouse_y:
      y = randint(0, max_y)
    
    remaining_time = randint(1, max_remaining_time)

    product = Product(product_identifier, x, y, remaining_time)

    list_of_products.append(product)
  
  return list_of_products

def algorithm(max_iterations, list_of_vehicles, list_of_products, city, warehouse_x, warehouse_y):
  best_solution_vehicles, best_solution_products, best_fitness = grasp(max_iterations, list_of_vehicles, list_of_products, warehouse_x, warehouse_y)

  for vehicle, product in zip(best_solution_vehicles, best_solution_products):
    initial = (vehicle.x, vehicle.y)
    goal = (product.x, product.y)

    search_problem = SearchProblem(city, initial, goal)
    path = astar_search(search_problem, manhattan_dist)

    if path == None:
      path = list()
    
    x, y = goal[0], goal[1]

    if search_problem.city.is_blocked(x, y):
      flag = False
    else:
      flag = True

    path[-1] = (x, y, flag)
  
    vehicle.update_path(path)
  
  return best_solution_vehicles, best_solution_products, best_fitness

def make_solution_report(best_solution_vehicles, best_solution_products):
  for vehicle, product in zip(best_solution_vehicles, best_solution_products):
    vehicle_type = "Motorcycle" if isinstance(vehicle, Motorcycle) else "Car"

    print("Vehicle {} {} in Product {} with path {}".format(vehicle_type, vehicle.identifier, product.identifier, vehicle.path))